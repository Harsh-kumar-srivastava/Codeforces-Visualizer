package com.example.codeforcesviewer.UserData.SubmissionData

data class Member(
        val handle: String
)